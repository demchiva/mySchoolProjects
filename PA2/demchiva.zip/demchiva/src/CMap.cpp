#include "CMap.hpp"

void CMap::MemoryAl(){
    map = new char*[hight];
    for (int count = 0; count < hight; count++)
        map[count] = new char[width];
}

void CMap::SetB(CBonus *bonus, int v){
    bonus->ActivateBonus();
    pair<int, int> c(freeZones[v].first, freeZones[v].second);
    bonus->SetCoord(c);
}

void CMap::EnemyNextStep(){
    for( unsigned int k = 0; k < yellowEnemies.size(); k++ ){
        yellowEnemies[k].NextStep(yellowEnemies[k].GetCoord().first, yellowEnemies[k].GetCoord().second, map, pacman.GetCoordinates().first, pacman.GetCoordinates().second);
    }
    for( unsigned int k = 0; k < blueEnemies.size(); k++ ){
        blueEnemies[k].NextStep(blueEnemies[k].GetCoord().first, blueEnemies[k].GetCoord().second, map, pacman.GetCoordinates().first, pacman.GetCoordinates().second);
    }
    for( unsigned int k = 0; k < greenEnemies.size(); k++ ){
        greenEnemies[k].NextStep(greenEnemies[k].GetCoord().first, greenEnemies[k].GetCoord().second, map, pacman.GetCoordinates().first, pacman.GetCoordinates().second);
    }
}

void CMap::SetEnemies(){
    int curEn = 0;
    for( unsigned int i = 0; i < enemyZone.size(); i++ ){
        if ( curEn < configuration.GetNumberOfEnemies() ){
            map[enemyZone[i].first][enemyZone[i].second] = 'E';
            if ( curEn % 3 == 0 ){
                CYellowEnemy enemy;
                enemies.push_back(&enemy);
                enemy.SetCoord(enemyZone[i].first,  enemyZone[i].second, map, pacman.GetCoordinates().first, pacman.GetCoordinates().second);
                enemy.SetLevel(enemyLevel);
                yellowEnemies.push_back(enemy);
            }
            else if ( curEn % 3 == 1 ){
                CBlueEnemy enemy;
                enemies.push_back(&enemy);
                enemy.SetCoord(enemyZone[i].first,  enemyZone[i].second, map, pacman.GetCoordinates().first, pacman.GetCoordinates().second);
                enemy.SetLevel(enemyLevel);
                blueEnemies.push_back(enemy);
            }
            else{
                CGreenEnemy enemy;
                enemies.push_back(&enemy);
                enemy.SetCoord(enemyZone[i].first,  enemyZone[i].second, map, pacman.GetCoordinates().first, pacman.GetCoordinates().second);
                enemy.SetLevel(enemyLevel);
                greenEnemies.push_back(enemy);
            }
            curEn++;
            map[enemyZone[i].first][enemyZone[i].second] = ' ';
        }
        else{
            map[enemyZone[i].first][enemyZone[i].second] = ' ';
        }
    }
}

bool CMap::CheckYellowEnemy(int i, int j){
    for( unsigned int k = 0; k < yellowEnemies.size(); k++ ){
        if ( yellowEnemies[k].GetCoord().first == i
            && yellowEnemies[k].GetCoord().second == j ){
            return true;
        }
    }
    return false;
}

bool CMap::CheckBlueEnemy(int i, int j){
    for( unsigned int k = 0; k < blueEnemies.size(); k++ ){
        if ( blueEnemies[k].GetCoord().first == i
            && blueEnemies[k].GetCoord().second == j ){
            return true;
        }
    }
    return false;
}

bool CMap::CheckGreenEnemy(int i, int j){
    for( unsigned int k = 0; k < greenEnemies.size(); k++ ){
        if ( greenEnemies[k].GetCoord().first == i
            && greenEnemies[k].GetCoord().second == j ){
            return true;
        }
    }
    return false;
}

bool CMap::CheckAllEnemy(int i, int j){
    if ( CheckBlueEnemy(i, j) ||
        CheckGreenEnemy(i, j) ||
        CheckYellowEnemy(i, j)){
        return true;
    }
    return false;
}

CMap::CMap(string file){
    ifstream File(file);
    string line;
    
    getline ( File, line );
    width = atoi ( line.c_str() );
    getline ( File, line );
    hight = atoi ( line.c_str() );
    
    MemoryAl();
    
    pair<int, int> pacCoordinates;
    coinsNumber = 0;
    
    int j = 0;
    while(getline(File, line)){
        for(unsigned int i = 0; i < line.size(); i++){
            if ( line[i] == '.' ){
                map[j][i] = '.';
                freeZones.push_back(make_pair(j, i));
                coinsNumber++;
            }
            else if ( line[i] == '#' ){
                map[j][i] = '#';
            }
            else if ( line[i] == '<' ){
                pacCoordinates.second = j;
                pacCoordinates.first = i;
                map[j][i] = ' ';
                start.first = j;
                start.second = i;
            }
            else if ( line[i] == 'E' ){
                pair<int, int> NewEnemyZone;
                NewEnemyZone.first = j;
                NewEnemyZone.second = i;
                map[j][i] = ' ';
                enemyZone.push_back(NewEnemyZone);
            }
            else{
                map[j][i] = ' ';
            }
        }
        j++;
    }
    configuration = CConfiguration("./examples/configuration.txt");
    enemyLevel = configuration.GetEnemyLevel();
    pacman = CPacman(configuration.GetNumberOfLives(), pacCoordinates.second, pacCoordinates.first);
    SetEnemies();
    RandBonus();
}

CMap::~CMap(){
    for (int i = 0; i < hight; i++) {
        delete []map[i];
    }
    delete []map;
}

pair<bool, int> CMap::PrintMap(){
    if( coinsNumber == 0 ){
        pair<bool, int> result;
        result.first = true;
        result.second = 1;
        return result;
    }
    clear();
    for (int i = 0; i < hight; i++){
        for(int j = 0; j < width; j++){
            if ( pacman.CheckCoordinates(i, j) &&
                CheckAllEnemy(i, j)){
                if ( !pacman.CheckInv() ){
                    pacman.IncLives();
                    if ( pacman.CheckDeath() ){
                        pair<bool, int> result;
                        result.first = true;
                        result.second = -1;
                        return result;
                    }
                    pacman.SetCoordinates(start);
                }
            }
            if ( pacman.CheckCoordinates(i, j)){
                if ( pacman.GetColor() == 0 ){
                    attron( COLOR_PAIR( COLOR_ENEMY2 ) );
                }
                else{
                    attron( COLOR_PAIR( COLOR_ENEMY1 ) );
                }
                printw("%c", pacman.GetSymbol());
            }
            else if( bonusH.CheckCoord(i, j) ){
                attron( COLOR_PAIR( COLOR_TEXT ) );
                printw("@");
            }
            else if( bonusI.CheckCoord(i, j) ){
                attron( COLOR_PAIR( COLOR_BONUS2 ) );
                printw("@");
            }
            else if ( CheckBlueEnemy(i, j) ){
                attron( COLOR_PAIR( COLOR_WINDOW ) );
                printw("B");
            }
            else if ( CheckGreenEnemy(i, j) ){
                attron( COLOR_PAIR( COLOR_TEXT ) );
                printw("G");
            }
            else if ( CheckYellowEnemy(i, j) ){
                attron( COLOR_PAIR( COLOR_ENEMY2 ) );
                printw("Y");
            }
            else if ( map[i][j] != '.' ){
                attron( COLOR_PAIR( COLOR_DEFAULT ) );
                printw("%c", map[i][j]);
            }
            else{
                attron( COLOR_PAIR( COLOR_ENEMY1 ) );
                printw("%c", map[i][j]);
            }
            
        }
        printw("\n");
        EnemyNextStep();
    }
    printw("\n");
    attron( COLOR_PAIR( COLOR_DEFAULT ) );
    string health = " Lives: ";
    for(unsigned int i = 0; i < health.size(); i++){
        printw("%c", health[i]);
    }
    attron( COLOR_PAIR( COLOR_ENEMY2 ) );
    for( int i = 0; i < pacman.GetLive(); i++ ){
        printw("<3 ");
    }
    printw("\n");
    pair<bool, int> result;
    result.first = false;
    result.second = -1;
    return result;
}

void CMap::ForwardPressed(){
    if ( map[pacman.GetCoordinates().first - 1][pacman.GetCoordinates().second] != '#' ){
        if (  map[pacman.GetCoordinates().first - 1][pacman.GetCoordinates().second] == '.'  ){
            map[pacman.GetCoordinates().first - 1][pacman.GetCoordinates().second] = ' ';
            coinsNumber--;
        }
        pacman.MoveUp();
    }
    RandBonus();
    EnemyNextStep();
}

void CMap::BackPressed(){
    if ( map[pacman.GetCoordinates().first + 1][pacman.GetCoordinates().second] != '#' ){
        if ( map[pacman.GetCoordinates().first + 1][pacman.GetCoordinates().second] == '.' ){
            map[pacman.GetCoordinates().first + 1][pacman.GetCoordinates().second] = ' ';
            coinsNumber--;
        }
        pacman.MoveDown();
    }
    RandBonus();
    EnemyNextStep();
}

void CMap::LeftPressed(){
    if ( map[pacman.GetCoordinates().first][pacman.GetCoordinates().second - 1] != '#' ){
        if ( map[pacman.GetCoordinates().first][pacman.GetCoordinates().second - 1] == '.' ){
            map[pacman.GetCoordinates().first][pacman.GetCoordinates().second - 1] = ' ';
            coinsNumber--;
        }
        pacman.MoveLeft();
    }
    RandBonus();
    EnemyNextStep();
}

void CMap::RightPressed(){
    if ( map[pacman.GetCoordinates().first][pacman.GetCoordinates().second + 1] != '#' ){
        if ( map[pacman.GetCoordinates().first][pacman.GetCoordinates().second + 1] == '.' ){
            map[pacman.GetCoordinates().first][pacman.GetCoordinates().second + 1] = ' ';
            coinsNumber--;
        }
        pacman.MoveRight();
    }
    RandBonus();
    EnemyNextStep();
}

void CMap::RandBonus(){
    if ( pacman.GetCoordinates() == bonusI.GetCoord() && bonusI.GetAct() == true ){
        pacman.StartInv();
        bonusI.DiActivateBonus();
    }
    if ( pacman.GetCoordinates() == bonusH.GetCoord() && bonusH.GetAct() == true ){
        pacman.AddLives();
        bonusH.DiActivateBonus();
    }
    if ( bonusH.GetAct() || bonusI.GetAct() ){
        return;
    }
    int v = rand() % freeZones.size() + 1;
    int b = rand() % 10;
    if ( b % 2 == 0 ){
        SetB(&bonusH, v);
    }
    else{
        SetB(&bonusI, v);
    }
}
