#ifndef CGreenEnemy_hpp
#define CGreenEnemy_hpp

#include "CEnemy.hpp"

/*!
 * \brief A class that represents green enemies
 * Is a child class of CEnemy
 */

class CGreenEnemy:public CEnemy{
public:
    /*!
     * \brief Constructor
     */
    CGreenEnemy();
    
};

#endif
