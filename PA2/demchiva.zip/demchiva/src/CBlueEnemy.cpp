#include "CBlueEnemy.hpp"

CBlueEnemy::CBlueEnemy(){
    color = "blue";
    symbol = 'B';
}

