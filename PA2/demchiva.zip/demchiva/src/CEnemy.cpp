#include "CEnemy.hpp"

void CEnemy::nStep(CEnemyStrategy *str, char **map){
    str->CalculateNextStep(map);
    coordinates.first = str->GetNextStep().first;
    coordinates.second = str->GetNextStep().second;
}

CEnemy::CEnemy(){}

char CEnemy::GetSymbol(){
    return symbol;
}

void CEnemy::SetLevel(int l){
    level = l;
}

void CEnemy::SetCoord(int i, int j, char **map, int pI, int pJ){
    coordinates.first = i;
    coordinates.second = j;
}

void CEnemy::NextStep(int i, int j, char **map, int pI, int pJ){
    time_counter++;
    if (time_counter == 400 - 100 * level) {
        if ( level == 1 ){
            CStupidStrategy str(i, j, pI, pJ);
            nStep(&str, map);
        }
        else if ( level == 2 ){
            CNormalStrategy str(i, j, pI, pJ);
            nStep(&str, map);
        }
        else{
            CSmartStrategy str(i, j, pI, pJ);
            nStep(&str, map);
        }
        time_counter = 0;
    }
}

pair<int, int> CEnemy::GetCoord(){
    return coordinates;
}

string CEnemy::GetColor(){
    return color;
}
