#include "CBonus.hpp"

CBonus::CBonus(){
    symbol = '@';
    active = false;
}

void CBonus::SetCoord(pair<int, int> c){
    coordinates = c;
}

pair<int, int> CBonus::GetCoord(){
    return coordinates;
}

char CBonus::GetSymbol(){
    return symbol;
}

string CBonus::GetColor(){
    return color;
}

void CBonus::ActivateBonus(){
    active = true;
}

void CBonus::DiActivateBonus(){
    active = false;
}

bool CBonus::GetAct(){
    return active;
}

bool CBonus::CheckCoord(int i, int j){
    if ( active == false ){
        return false;
    }
    if ( coordinates.first == i && coordinates.second == j ){
        return true;
    }
    return false;
}
