#include "CNormalStrategy.hpp"

CNormalStrategy::CNormalStrategy(int i, int j, int pi, int pj): CEnemyStrategy(i, j, pi, pj){}

void CNormalStrategy::CalculateNextStep(char **map){
    nextStep.first = currentStep.first;
    nextStep.second = currentStep.second;
    if ( currentStep.first > purpose.first ){
        if ( map[currentStep.first - 1][currentStep.second] != '#' ){
            nextStep.first = currentStep.first - 1;
            nextStep.second = currentStep.second;
            return;
        }
    }
    else if ( currentStep.first < purpose.first ){
        if ( map[currentStep.first + 1][currentStep.second] != '#' ){
            nextStep.first = currentStep.first + 1;
            nextStep.second = currentStep.second;
            return;
        }
    }
    
    else if ( currentStep.second > purpose.second ){
        if ( map[currentStep.first][currentStep.second - 1] != '#' ){
            nextStep.first = currentStep.first;
            nextStep.second = currentStep.second - 1;
            return;
        }
    }
    else if ( currentStep.second < purpose.second ){
        if ( map[currentStep.first][currentStep.second + 1] != '#' ){
            nextStep.first = currentStep.first;
            nextStep.second = currentStep.second + 1;
            return;
        }
    }
    int st = rand() % 4;
    if ( st % 4 == 0 ){
        if ( map[currentStep.first][currentStep.second - 1] != '#' ){
            nextStep.first = currentStep.first;
            nextStep.second = currentStep.second - 1;
            return;
        }
        else{
            st++;
        }
    }
    if ( st % 4 == 1 ){
        if ( map[currentStep.first][currentStep.second + 1] != '#' ){
            nextStep.first = currentStep.first;
            nextStep.second = currentStep.second + 1;
            return;
        }
        else{
            st++;
        }
    }
    if ( st % 4 == 2 ){
        if ( map[currentStep.first - 1][currentStep.second] != '#' ){
            nextStep.first = currentStep.first - 1;
            nextStep.second = currentStep.second;
            return;
        }
        else{
            st++;
        }
    }
    {
        if ( map[currentStep.first + 1][currentStep.second] != '#' ){
            nextStep.first = currentStep.first + 1;
            nextStep.second = currentStep.second;
            return;
        }
    }
}
