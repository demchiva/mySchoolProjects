#ifndef CBonus_hpp
#define CBonus_hpp

#include <string>
#include <utility>

using namespace std;

/*!
 * \brief Virtual class that represents bonuses in game
 */

class CBonus{
protected:
    char                symbol;       //!< bonus symbol
    bool                active;       //!< bonus activity
    string              color;        //!< bonus color
    pair<int, int>      coordinates;  //!< bonus coordinates
public:
    
    /*!
     * \brief constructor
     */
    CBonus();
    
    /*!
     * \brief Setting new coordinates
     * @param[in] c - new coordinates
     */
    void SetCoord(pair<int, int> c);
    
    /*!
     * \brief virtual method for returning bonus coordinates on the map
     * @return coordinates
     */
    pair<int, int> GetCoord();
    
    /*!
     * \brief virtual method for returning bonus symbol on the map
     * @return symbol
     */
    char GetSymbol();
    
    /*!
     * \brief virtual method for returning bonus symbol color
     * @return color name
     */
    string GetColor();
    
    /*!
     * \brief virtual method for activating bonus
     */
    void ActivateBonus();
    
    /*!
     * \brief virtual method for diactivating bonus
     */
    void DiActivateBonus();
    
    /*!
     * \brief virtual method for returning bonus activity
     * @return activity
     */
    bool GetAct();
    
    /*!
     * \brief virtual method for checking bonus on input coordinates
     * @param[in] i, j - coordinates
     * @return true/false
     */
    bool CheckCoord(int i, int j);
    
};

#endif
