#ifndef CPacman_hpp
#define CPacman_hpp

#include <utility>

using namespace std;

/*!
 * \brief Virtual class that represents pacman
 */

class CPacman{
private:
    int                 lives;          //!< number of lives
    pair<int, int>      coordinates;    //!< coordinates
    char                symbol;         //!< symbol on map
    bool                actInv;         //!< bonus activity
    int                 InvSteps = 25;  //!< steps
public:
    /*!
     * empty constructor
     */
    CPacman();
    
    /*!
     * Constructor
     * @param[in] i, j - coordinates
     * @param[in] l - level
     */
    CPacman(int l, int i, int j);
    
    /*!
     * \brief Getting color
     * @return color
     */
    int GetColor();
    
    /*!
     * \brief checking coordinates
     * @param[in] i, j - coordinates
     * @return true/false
     */
    bool CheckCoordinates(int i, int j);
    
    /*!
     * \brief Getting coordinates
     * @return coordinates
     */
    pair<int, int> GetCoordinates();
    
    /*!
     * \brief Getting symbol
     * @return symbol
     */
    char GetSymbol();
    
    /*!
     * \brief Getting lives
     * @return lives
     */
    int GetLive();
    
    /*!
     * \brief subbing live
     */
    void IncLives();
    
    /*!
     * \brief adding live
     */
    void AddLives();
    
    void SetCoordinates(pair<int, int> newCoord);
    
    /*!
     * \brief checking lives
     * @return true/false
     */
    bool CheckDeath();
    
    /*!
     * \brief starting bonus activity
     */
    void StartInv();
    
    /*!
     * \brief checking bonus activity
     * @return true/false
     */
    bool CheckInv();
    
    /*!
     * \brief moving up
     */
    void MoveUp();
    
    /*!
     * \brief moving down
     */
    void MoveDown();
    
    /*!
     * \brief moving right
     */
    void MoveRight();
    
    /*!
     * \brief moving left
     */
    void MoveLeft();
    
};

#endif
