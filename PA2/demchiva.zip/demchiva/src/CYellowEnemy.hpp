#ifndef CYellowEnemy_hpp
#define CYellowEnemy_hpp

#include "CEnemy.hpp"

/*!
 * \brief A class that represents yellow enemies
 * Is a child class of CEnemy
 */

class CYellowEnemy:public CEnemy{
public:
    /*!
     * \brief Constructor
     */
    CYellowEnemy();
    
};


#endif
