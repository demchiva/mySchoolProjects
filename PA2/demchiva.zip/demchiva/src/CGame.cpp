#include "CGame.hpp"

void CGame::StartGame(){
    timeout(0);
    int res = 0;
    CMap map("./examples/map.txt");
    while(1){
        int key_code;
        if ( map.PrintMap().first == true ){
            clear();
            res = map.PrintMap().second;
            break;
        }
        while ((key_code = getch()) > 0){
            switch(key_code){
                case (int)KEY_UP:
                    map.ForwardPressed();
                    break;
                case (int)KEY_DOWN:
                    map.BackPressed();
                    break;
                case (int)KEY_LEFT:
                    map.LeftPressed();
                    break;
                case (int)KEY_RIGHT:
                    map.RightPressed();
                    break;
                    
                default:
                    break;
            }
        }
        usleep(40000);
    }
    
    while(1){
        clear();
        if ( res == 1 ){
            attron( COLOR_PAIR( COLOR_TEXT ) );
            mvprintw(screenSizeY / 2 - 12, screenSizeX / 2 - 13, "WIN");
        }
        else{
            attron( COLOR_PAIR( COLOR_ENEMY2 ) );
            mvprintw(screenSizeY / 2 - 12, screenSizeX / 2 - 13, "LOSE");
        }
        int c;
        c = getch();
        if ( c == (int)Enter ){
            break;
        }
    }
    
}

void CGame::StandartSettings(){
    initscr();
    noecho();
    cbreak();
    curs_set(0);
    keypad ( stdscr, true );
    int x, y;
    getmaxyx(stdscr, y, x);
    screenSizeX = x;
    screenSizeY = y;
    start_color();
    init_pair(COLOR_DEFAULT, COLOR_WHITE, COLOR_BLACK);
    init_pair(COLOR_WALL, COLOR_WHITE, COLOR_BLACK);
    init_pair(COLOR_STAR, COLOR_WHITE, COLOR_BLACK);
    init_pair(COLOR_SHIP, COLOR_GREEN, COLOR_BLACK);
    init_pair(COLOR_TURBINE, COLOR_YELLOW, COLOR_BLACK);
    init_pair(COLOR_FIRE1, COLOR_BLUE, COLOR_BLACK);
    init_pair(COLOR_FIRE2, COLOR_RED, COLOR_BLACK);
    init_pair(COLOR_BOSS, COLOR_RED, COLOR_BLACK);
    init_pair(COLOR_ENEMY1, COLOR_YELLOW, COLOR_BLACK);
    init_pair(COLOR_ENEMY2, COLOR_RED, COLOR_BLACK);
    init_pair(COLOR_BONUS1, COLOR_GREEN, COLOR_BLACK);
    init_pair(COLOR_BONUS2, COLOR_MAGENTA, COLOR_BLACK);
    init_pair(COLOR_WEAPON1, COLOR_RED, COLOR_BLACK);
    init_pair(COLOR_WEAPON2, COLOR_RED, COLOR_BLACK);
    init_pair(COLOR_CHOOSE, COLOR_YELLOW, COLOR_BLACK);
    init_pair(COLOR_NOCHOOSE, COLOR_RED, COLOR_BLACK);
    init_pair(COLOR_TEXT, COLOR_GREEN, COLOR_BLACK);
    init_pair(COLOR_SPACE, COLOR_BLACK, COLOR_BLACK);
    init_pair(COLOR_WINDOW, COLOR_BLUE, COLOR_BLACK);
}

void CGame::StartMenu(){
    clear();
    int selected = 0;
    int pressed = 0;
    
    attron( COLOR_PAIR( COLOR_ENEMY1 ) );
    mvprintw(screenSizeY / 2 - 12, screenSizeX / 2 - 13, "         Pacman");
    
    attron( COLOR_PAIR( COLOR_DEFAULT ) );
    WINDOW * startWindow = newwin( 3, 25, screenSizeY / 2 - 10, screenSizeX / 2 - 12 );
    AddOption( *startWindow, "  Start Game");
    SetColor( *startWindow, COLOR_DEFAULT );
    
    WINDOW * recordWindow = newwin( 3, 25, screenSizeY / 2 - 7, screenSizeX / 2 - 12 );
    AddOption( *recordWindow, "    Quit");
    
    while ( pressed != Enter )
    {
        if      ( pressed == (int)KEY_UP )        selected --;
        else if ( pressed == (int)KEY_DOWN )      selected ++;
        
        SetColor( *startWindow, COLOR_DEFAULT );
        SetColor( *recordWindow, COLOR_DEFAULT );
        
        switch ( selected )
        {
            case 0 :
                SetColor( *startWindow, COLOR_CHOOSE );
                break;
            case 1:
                SetColor( *recordWindow, COLOR_CHOOSE );
                break;
            case 2:
                selected = 0;
                SetColor( *startWindow, COLOR_CHOOSE );
                break;
            case -1:
                selected = 1;
                SetColor( *recordWindow, COLOR_CHOOSE );
                break;
        }
        pressed = getch ();
    }
    switch ( selected ){
        case 0 :
            StartGame();
            StartMenu();
            break;
        case 1:
            return;
            break;
        default:
            break;
    }
}
