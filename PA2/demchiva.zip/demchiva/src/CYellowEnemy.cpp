#include "CYellowEnemy.hpp"

CYellowEnemy::CYellowEnemy(){
    color = "yellow";
    symbol = 'Y';
}

