#include "CStupidStrategy.hpp"

CStupidStrategy::CStupidStrategy(int i, int j, int pi, int pj): CEnemyStrategy(i, j, pi, pj){}

void CStupidStrategy::CalculateNextStep(char **map){
    int st = rand() % 4;
    nextStep = currentStep;
    if ( st % 4 == 0 ){
        if ( map[currentStep.first][currentStep.second - 1] != '#' ){
            nextStep.first = currentStep.first;
            nextStep.second = currentStep.second - 1;
            return;
        }
        else{
            st++;
        }
    }
    if ( st % 4 == 1 ){
        if ( map[currentStep.first][currentStep.second + 1] != '#' ){
            nextStep.first = currentStep.first;
            nextStep.second = currentStep.second + 1;
            return;
        }
        else{
            st++;
        }
    }
    if ( st % 4 == 2 ){
        if ( map[currentStep.first - 1][currentStep.second] != '#' ){
            nextStep.first = currentStep.first - 1;
            nextStep.second = currentStep.second;
            return;
        }
        else{
            st++;
        }
    }
    {
        if ( map[currentStep.first + 1][currentStep.second] != '#' ){
            nextStep.first = currentStep.first + 1;
            nextStep.second = currentStep.second;
            return;
        }
    }
}
