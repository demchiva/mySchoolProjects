#include "CSmartStrategy.hpp"

CSmartStrategy::CSmartStrategy(int i, int j, int pi, int pj): CEnemyStrategy(i, j, pi, pj){}

void CSmartStrategy::CalculateNextStep(char **map){
    nextStep.first = currentStep.first;
    nextStep.second = currentStep.second;
    if ( currentStep.first > purpose.first ){
        if ( map[currentStep.first - 1][currentStep.second] != '#' ){
            nextStep.first = currentStep.first - 1;
            nextStep.second = currentStep.second;
            return;
        }
    }
    if ( currentStep.first < purpose.first ){
        if ( map[currentStep.first + 1][currentStep.second] != '#' ){
            nextStep.first = currentStep.first + 1;
            nextStep.second = currentStep.second;
            return;
        }
    }
    
    if ( currentStep.second > purpose.second ){
        if ( map[currentStep.first][currentStep.second - 1] != '#' ){
            nextStep.first = currentStep.first;
            nextStep.second = currentStep.second - 1;
            return;
        }
    }
    if ( currentStep.second < purpose.second ){
        if ( map[currentStep.first][currentStep.second + 1] != '#' ){
            nextStep.first = currentStep.first;
            nextStep.second = currentStep.second + 1;
            return;
        }
    }
}
