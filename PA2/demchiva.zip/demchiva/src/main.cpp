#include <ncurses.h>

#include "CGame.hpp"

int main(int argc, const char * argv[]) {
    
    CGame game;
    game.StandartSettings();
    game.StartMenu();
    endwin();
    
    return 0;
}
