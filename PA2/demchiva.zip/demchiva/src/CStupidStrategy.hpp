#ifndef CStupidStrategy_hpp
#define CStupidStrategy_hpp

#include "CEnemyStrategy.hpp"
#include <stdlib.h>

/*!
 * \brief Virtual class that represents enemy stupid strategy
 * \brief Virtual class of CEnemyStrategy
 */

class CStupidStrategy: public CEnemyStrategy{
public:
    /*!
     * \brief constructor
     * @param[in] i, j - enemy coordinates
     * @param[in] pi, pj - pacman coordinates
     */
    CStupidStrategy(int i, int j, int pi, int pj);
    
    /*!
     * Function for calculating enemy's next step
     * @param[in] map - map
     */
    void CalculateNextStep(char **map) override;
    
};

#endif
