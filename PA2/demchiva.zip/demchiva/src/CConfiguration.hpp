#ifndef CConfiguration_hpp
#define CConfiguration_hpp

#include <fstream>
#include <sstream>
#include <string>

using namespace std;

/*!
 * \brief Virtual class that represents game configuration
 */

class CConfiguration{
private:
    int     NumberOfEnemies;    //!< number of enemies
    int     EnemyLevel;         //!< enemy level
    int     PacmanLevel;        //!< pacman level
    
public:
    /*!
     * \brief constructor
     */
    CConfiguration();
    
    /*!
     * \brief Reading configuration from file
     * @param[in] file - file with configuration
     */
    CConfiguration(string file);
    
    /*!
     * \brief virtual method for returning number of enemies
     * @return number of enemies
     */
    int GetNumberOfEnemies();
    
    /*!
     * \brief virtual method for returning number of pacman lives
     * @return number of pacman lives
     */
    int GetNumberOfLives();
    
    /*!
     * \brief virtual method for returning number of enemy level
     * @return number of enemy level
     */
    int GetEnemyLevel();
    
};

#endif
