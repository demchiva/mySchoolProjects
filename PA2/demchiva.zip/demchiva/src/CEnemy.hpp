#ifndef CEnemy_hpp
#define CEnemy_hpp

#include <string>
#include <utility>

#include "CEnemyStrategy.hpp"
#include "CStupidStrategy.hpp"
#include "CNormalStrategy.hpp"
#include "CSmartStrategy.hpp"

using namespace std;

/*!
 * \brief Virtual class that represents enemies in game
 */

class CEnemy {
protected:
    char            symbol;            //!< symbol on map
    string          color;             //!< color on map
    pair<int, int>  coordinates;       //!< coordinates on map
    int             level;             //!< difficult level
    int             time_counter = 0;  //!< time counter for detecting speed
    
    /*!
     * Function for calculating enemy's next step
     * @param[in] str - strategy
     * @param[in] map - map
     */
    void nStep(CEnemyStrategy *str, char **map);
    
public:
    /*!
     * Constructor
     */
    CEnemy();
    
    /*!
     * \brief Getting enemy symbol
     * @return symbol
     */
    char GetSymbol();
    
    /*!
     * \brief Setting new level
     * @param[in] l - new level
     */
    void SetLevel(int l);
    
    /*!
     * \brief Setting new coordinates
     * @param[in] i, j - enemy coordinates
     * @param[in] map - map
     * @param[in] pi, pj - pacman coordinates
     */
    void SetCoord(int i, int j, char **map, int pI, int pJ);
    
    /*!
     * \brief Calculating next step
     * @param[in] i, j - enemy coordinates
     * @param[in] map - map
     * @param[in] pi, pj - pacman coordinates
     */
    void NextStep(int i, int j, char **map, int pI, int pJ);
    
    /*!
     * \brief Getting coordinates
     * @return coordinates
     */
    pair<int, int> GetCoord();
    
    /*!
     * \brief Getting color
     * @return color
     */
    string GetColor();
    
};

#endif
