#ifndef CEnemyStrategy_hpp
#define CEnemyStrategy_hpp

#include <utility>
#include <vector>

using namespace std;

/*!
 * \brief Virtual class that represents enemy strategy
 */

class CEnemyStrategy{
protected:
    pair<int, int>              currentStep;    //!< current step coordinates
    pair<int, int>              nextStep;       //!< next step coordinates
    vector< pair<int, int> >    stepsVector;    //!< vector of steps coordinates
    pair<int, int>              purpose;        //!< purpose coordinates
public:
    /*!
     * \brief constructor
     * @param[in] i, j - enemy coordinates
     * @param[in] pi, pj - pacman coordinates
     */
    CEnemyStrategy(int i, int j, int pi, int pj);
    
    /*!
     * Function for calculating enemy's next step
     * @return next step coordinates
     */
    pair<int, int> GetNextStep();
    
    /*!
     * Function for calculating enemy's next step
     * @param[in] map - map
     */
    virtual void CalculateNextStep(char **map) = 0;
    
};

#endif
