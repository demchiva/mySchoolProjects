#include "CEnemyStrategy.hpp"

CEnemyStrategy::CEnemyStrategy(int i, int j, int pi, int pj){
    currentStep.first = i;
    currentStep.second = j;
    purpose.first = pi;
    purpose.second = pj;
}

pair<int, int> CEnemyStrategy::GetNextStep(){
    return nextStep;
}
