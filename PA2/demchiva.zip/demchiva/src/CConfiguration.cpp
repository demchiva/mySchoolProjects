#include "CConfiguration.hpp"

CConfiguration::CConfiguration(){}

CConfiguration::CConfiguration(string file){
    ifstream File(file);
    string line;
    getline ( File, line );
    getline ( File, line );
    NumberOfEnemies = atoi ( line.c_str() );
    getline ( File, line );
    getline ( File, line );
    EnemyLevel = atoi ( line.c_str() );
    getline ( File, line );
    getline ( File, line );
    PacmanLevel = atoi ( line.c_str() );
}

int CConfiguration::GetNumberOfEnemies(){
    return NumberOfEnemies;
}

int CConfiguration::GetNumberOfLives(){
    return PacmanLevel;
}

int CConfiguration::GetEnemyLevel(){
    return EnemyLevel;
}
