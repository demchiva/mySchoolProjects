#ifndef CGame_hpp
#define CGame_hpp

#include <ctime>
#include <unistd.h>

#include "CFunctions.hpp"
#include "CMap.hpp"

/*!
 * \brief A class that represents game action
 */

class CGame{
private:
    int         screenSizeX;   //!< Screen height
    int         screenSizeY;   //!< Screen width
    
    /*!
     * \brief Method for playing
     */
    void StartGame();
    
public:
    /*!
     * \brief Method for setting standart settings
     */
    void StandartSettings();
    
    /*!
     * \brief Method for showing menu
     */
    void StartMenu();
    
};

#endif
