#ifndef CSmartStrategy_hpp
#define CSmartStrategy_hpp

#include "CEnemyStrategy.hpp"

/*!
 * \brief Virtual class that represents enemy smart strategy
 * \brief child class of CEnemyStrategy
 */

class CSmartStrategy: public CEnemyStrategy{
public:
    /*!
     * \brief constructor
     * @param[in] i, j - enemy coordinates
     * @param[in] pi, pj - pacman coordinates
     */
    CSmartStrategy(int i, int j, int pi, int pj);
    
    /*!
     * Function for calculating enemy's next step
     * @param[in] map - map
     */
    void CalculateNextStep(char **map) override;
    
};

#endif
