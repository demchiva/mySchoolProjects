#include "CGreenEnemy.hpp"

CGreenEnemy::CGreenEnemy(){
    color = "green";
    symbol = 'G';
}
