#include "CPacman.hpp"

CPacman::CPacman(){}

CPacman::CPacman(int l, int i, int j){
    lives = l;
    coordinates.first = i;
    coordinates.second = j;
    symbol = '<';
    actInv = false;
}

int CPacman::GetColor(){
    if ( !actInv ){
        return 1;
    }
    return ( InvSteps % 2 );
}

bool CPacman::CheckCoordinates(int i, int j){
    if ( coordinates.first == i && coordinates.second == j ){
        return true;
    }
    return false;
}

pair<int, int> CPacman::GetCoordinates(){
    return coordinates;
}

char CPacman::GetSymbol(){
    return symbol;
}

int CPacman::GetLive(){
    return lives;
}

void CPacman::IncLives(){
    lives--;
}

void CPacman::AddLives(){
    lives++;
}

void CPacman::SetCoordinates(pair<int, int> newCoord){
    coordinates = newCoord;
}

bool CPacman::CheckDeath(){
    if ( lives == 0 ){
        return true;
    }
    return false;
}

void CPacman::StartInv(){
    actInv = true;
    InvSteps = 25;
}

bool CPacman::CheckInv(){
    return actInv;
}

void CPacman::MoveUp(){
    if ( actInv == true && InvSteps > 1 ){
        InvSteps--;
    }
    if ( InvSteps == 1 ){
        InvSteps = 25;
        actInv = false;
    }
    coordinates.first--;
    symbol = '^';
}

void CPacman::MoveDown(){
    if ( actInv == true && InvSteps >= 1 ){
        InvSteps--;
    }
    if ( InvSteps == 0 ){
        actInv = false;
    }
    coordinates.first++;
    symbol = 'V';
}

void CPacman::MoveRight(){
    if ( actInv == true && InvSteps >= 1 ){
        InvSteps--;
    }
    if ( InvSteps == 0 ){
        actInv = false;
    }
    coordinates.second++;
    symbol = '>';
}

void CPacman::MoveLeft(){
    if ( actInv == true && InvSteps >= 1 ){
        InvSteps--;
    }
    if ( InvSteps == 0 ){
        actInv = false;
    }
    coordinates.second--;
    symbol = '<';
}
