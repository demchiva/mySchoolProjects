#ifndef CBlueEnemy_hpp
#define CBlueEnemy_hpp

#include "CEnemy.hpp"

/*!
 * \brief A class that represents blue enemies
 * Is a child class of CEnemy
 */

class CBlueEnemy:public CEnemy{
private:
public:
    /*!
     * \brief Constructor
     */
    CBlueEnemy();
    
};

#endif
