#ifndef CMap_hpp
#define CMap_hpp

#include "CYellowEnemy.hpp"
#include "CBlueEnemy.hpp"
#include "CGreenEnemy.hpp"
#include "CHealthBonus.hpp"
#include "CInvulnerabilityBonus.hpp"
#include "CPacman.hpp"
#include "CConfiguration.hpp"
#include "CFunctions.hpp"

/*!
 * \brief Class that represents Game Map
 */

class CMap{
private:
    int                         width;          //!< Map's width
    int                         hight;          //!< Map's hight
    
    int                         enemyLevel;     //!< enemy level
    char                        **map;          //!< map
    int                         coinsNumber;    //!< coins number
    CPacman                     pacman;         //!< pacman
    CConfiguration              configuration;  //!< configuration
    vector< pair<int, int> >    enemyZone;      //!< enemy zones
    
    vector<CYellowEnemy>        yellowEnemies;  //!< yellow enemy vector
    vector<CBlueEnemy>          blueEnemies;    //!< blue enemy vector
    vector<CGreenEnemy>         greenEnemies;   //!< green enemy vector
    vector<CEnemy*>             enemies;        //!< enemies vector
    
    pair<int, int>              start;          //!< start coordinates
    vector< pair<int, int> >    freeZones;      //!< free zones
    
    CHealthBonus                bonusH;         //!< health bonus
    CInvulnerabilityBonus       bonusI;         //!< inv. bonus
    
    /*!
     * \brief Memory alocation for map
     */
    void MemoryAl();
    
    /*!
     * \brief setting bonus
     * @param[in] bonus - bonus
     * @param[in] v - letter
     */
    void SetB(CBonus *bonus, int v);
    
    /*!
     * \brief enemy next step
     */
    void EnemyNextStep();
    
    /*!
     * \brief setting enemies
     */
    void SetEnemies();
    
    /*!
     * \brief checking yellow enemies
     * @param[in] i, j - coordinates
     * @return true/false
     */
    bool CheckYellowEnemy(int i, int j);
    
    /*!
     * \brief checking blue enemies
     * @param[in] i, j - coordinates
     * @return true/false
     */
    bool CheckBlueEnemy(int i, int j);
    
    /*!
     * \brief checking green enemies
     * @param[in] i, j - coordinates
     * @return true/false
     */
    bool CheckGreenEnemy(int i, int j);
    
    /*!
     * \brief checking all enemies
     * @param[in] i, j - coordinates
     * @return true/false
     */
    bool CheckAllEnemy(int i, int j);
    
public:
    /*!
     * Constructor with map loading from file
     * @param[in] file - name of file
     */
    CMap(string file);
    
    /*!
     * Destructor
     */
    ~CMap();
    
    /*!
     * \brief Method for map printing
     * @return true/false
     */
    pair<bool, int> PrintMap();
    
    /*!
     * \brief Forward button pressed
     */
    void ForwardPressed();
    
    /*!
     * \brief Back button pressed
     */
    void BackPressed();
    
    /*!
     * \brief Left button pressed
     */
    void LeftPressed();
    
    /*!
     * \brief Right button pressed
     */
    void RightPressed();
    
    /*!
     * \brief Random bonus
     */
    void RandBonus();
  
};

#endif
