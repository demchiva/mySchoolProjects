#include "CHealthBonus.hpp"

CHealthBonus::CHealthBonus():CBonus(){
    color = "Green";
}
