#ifndef CFunctions_hpp
#define CFunctions_hpp

#include <string>
#include <ncurses.h>

using namespace std;

#define Enter 10                            ///< Key For pressing Enter
#define KEY_W 119                           ///< Key For pressing W
#define KEY_S 115                           ///< Key For pressing S
#define KEY_A 97                            ///< Key For pressing A
#define KEY_D 100                           ///< Key For pressing D

#define COLOR_DEFAULT 1                     ///< White color
#define COLOR_WALL 2                        ///< Bue color
#define COLOR_STAR 3                        ///< Yellow color
#define COLOR_SHIP 4                        ///< Red color
#define COLOR_TURBINE 5                     ///< Green color
#define COLOR_FIRE1 6                       ///< Red color
#define COLOR_FIRE2 7                       ///< Bue color
#define COLOR_BOSS 8                        ///< Yellow color
#define COLOR_ENEMY1 9                      ///< Pink color
#define COLOR_ENEMY2 10                     ///< Yellow color
#define COLOR_BONUS1 11                     ///< Pink color
#define COLOR_BONUS2 12                     ///< Bue color
#define COLOR_WEAPON1 13                    ///< Pink color
#define COLOR_WEAPON2 14                    ///< Green color
#define COLOR_CHOOSE 15                     ///< Bue color
#define COLOR_NOCHOOSE 16                   ///< Pink color
#define COLOR_TEXT 17                       ///< Red color
#define COLOR_SPACE 18                      ///< Green color
#define COLOR_WINDOW 19                     ///< Pink color

inline void SetColor(WINDOW & window, int pair){
    wbkgd(&window, COLOR_PAIR(pair));
    refresh();
    wrefresh(&window);
}

inline void SetColor(const int pair){
    attron(COLOR_PAIR(pair));
}

inline void AddOption( WINDOW & window, const string & label ){
    box ( &window, 0, 0 );
    mvwprintw ( &window, 1, 5, label.c_str() );
    wrefresh( &window );
    refresh();
}

inline string StringUserInput(){
    char c;
    string s = "";
    while(1){
        c = getch();
        if ( c == '\n' )
            break;
        printw("%c", c);
        s = s + c;
    }
    return s;
}

#endif
