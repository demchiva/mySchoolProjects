#ifndef CHealthBonus_hpp
#define CHealthBonus_hpp

#include "CBonus.hpp"

/*!
 * \brief A class that represents health bonus
 * Is a child class of CBonus
 */

class CHealthBonus: public CBonus{
public:
    /*!
     * \brief constructor
     */
    CHealthBonus();
    
};

#endif
